import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'voicecmd_model.dart';
export 'voicecmd_model.dart';

class VoicecmdWidget extends StatefulWidget {
  const VoicecmdWidget({Key? key}) : super(key: key);

  @override
  _VoicecmdWidgetState createState() => _VoicecmdWidgetState();
}

class _VoicecmdWidgetState extends State<VoicecmdWidget> {
  late VoicecmdModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VoicecmdModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Align(
            alignment: AlignmentDirectional(0.00, 0.00),
            child: Icon(
              Icons.mic_outlined,
              color: FlutterFlowTheme.of(context).tertiary,
              size: 80.0,
            ),
          ),
        ),
      ),
    );
  }
}
