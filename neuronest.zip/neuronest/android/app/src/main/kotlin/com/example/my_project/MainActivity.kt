package com.mycompany.neuronest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
